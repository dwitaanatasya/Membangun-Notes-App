class ButtonComponents extends HTMLElement {
    constructor() {
      super();
      const shadow = this.attachShadow({ mode: 'open' });
      const button = document.createElement('button');
      button.textContent = this.getAttribute('text');
      button.addEventListener('click', () => {
        const event = new CustomEvent(`${this.getAttribute('action')}-note`, {
          bubbles: true,
          composed: true,
          detail: { noteId: this.getAttribute('note-id') }
        });
        this.dispatchEvent(event);
      });
      shadow.appendChild(button);
    }
  }
  
  customElements.define('button-components', ButtonComponents);
  