import './note-component.js';
import './quote-component.js';
import './todo-component.js';
import './weather-component.js';
import './button-components.js';
import './archive-container-component.js';
import './add-note-form.js';


const notesComponent = document.getElementById('notes-component');
const loadingIndicator = document.getElementById('loading');

async function fetchNotes() {
  showLoading();
  try {
    const response = await fetch('https://notes-api.dicoding.dev/v2/notes');
    const apiData = await response.json();

    saveNotesToLocalStorage(apiData.data);
    renderNotes(apiData.data);
  } catch (error) {
    hideLoading();
    alert('Error fetching notes. Please try again later.');
    console.error('Error fetching notes:', error);
  } finally {
    hideLoading();
  }
}

function saveNotesToLocalStorage(notes) {
  localStorage.setItem('notes', JSON.stringify(notes));
}

function loadNotesFromLocalStorage() {
  const storedNotes = localStorage.getItem('notes');
  return storedNotes ? JSON.parse(storedNotes) : [];
}

function renderNotes(notesData) {
  notesComponent.innerHTML = '';
  notesData.forEach(note => {
    const noteComponent = document.createElement('note-component');
    noteComponent.setAttribute('note-data', JSON.stringify(note));
    notesComponent.appendChild(noteComponent);
  });
}

document.addEventListener('add-note', async function(event) {
  const newNote = event.detail;
  try {
    showLoading();
    const response = await fetch('https://notes-api.dicoding.dev/v2/notes', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(newNote),
    });

    if (!response.ok) {
      throw new Error('Failed to add note.');
    }

    const data = await response.json();
    saveNotesToLocalStorage(data);
    fetchNotes();
  } catch (error) {
    alert('Error adding note. Please try again later.');
    console.error('Error adding note:', error);
  } finally {
    hideLoading();
  }
});

async function archiveNote(noteId) {
  showLoading();
  try {
    const response = await fetch(`https://notes-api.dicoding.dev/v2/notes/${noteId}/archive`, {
      method: 'POST'
    });
    const data = await response.json();
    fetchNotes();
  } catch (error) {
    hideLoading();
    alert('Error archiving note. Please try again later.');
    console.error('Error archiving note:', error);
  } finally {
    hideLoading();
  }
}

async function deleteNote(noteId) {
  showLoading();
  try {
    const response = await fetch(`https://notes-api.dicoding.dev/v2/notes/${noteId}`, {
      method: 'DELETE'
    });
    const data = await response.json();
    fetchNotes();
  } catch (error) {
    hideLoading();
    alert('Error deleting note. Please try again later.');
    console.error('Error deleting note:', error);
  } finally {
    hideLoading();
  }
}

function showLoading() {
  loadingIndicator.style.display = 'block';
}

function hideLoading() {
  loadingIndicator.style.display = 'none';
}

let notesData = loadNotesFromLocalStorage();

renderNotes(notesData);
fetchNotes();
