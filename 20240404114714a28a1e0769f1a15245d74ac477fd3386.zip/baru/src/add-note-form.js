// add-note-form.js
class AddNoteForm extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
        <style>
          .add-note-container {
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
          }
  
          .add-note-container h2 {
            margin-top: 0;
            margin-bottom: 20px;
            color: #333;
          }
  
          .add-note-container input[type="text"],
          .add-note-container textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
          }
  
          .add-note-container button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
          }
  
          .add-note-container button[type="submit"]:hover {
            background-color: #0056b3;
          }
        </style>
        <div class="add-note-container">
          <h2>Add New Note</h2>
          <form id="add-note-form">
            <input type="text" id="note-title" placeholder="Title">
            <textarea id="note-body" placeholder="Body"></textarea>
            <button type="submit">Add Note</button>
          </form>
        </div>
      `;
        this.form = this.shadowRoot.querySelector('#add-note-form');
    }

    connectedCallback() {
        this.form.addEventListener('submit', this.handleFormSubmit.bind(this));
        this.addEventListener('add-note', this.handleAddNote.bind(this));
    }

    handleFormSubmit(event) {
        event.preventDefault();

        const titleInput = this.shadowRoot.getElementById('note-title');
        const bodyInput = this.shadowRoot.getElementById('note-body');
        const title = titleInput.value.trim();
        const body = bodyInput.value.trim();

        if (title === '' || body === '') {
            alert('Please fill in both title and body fields.');
            return;
        }

        const newNote = {
            title,
            body,
        };

        fetch('https://notes-api.dicoding.dev/v2/notes', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newNote),
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to add note.');
            }
            return response.json();
        })
        .then(data => {
            // Simpan catatan ke localStorage
            this.dispatchEvent(new CustomEvent('add-note', { detail: data }));
            // Bersihkan input setelah catatan ditambahkan
            titleInput.value = '';
            bodyInput.value = '';
        })
        .catch(error => {
            alert('Error adding note. Please try again later.');
            console.error('Error adding note:', error);
        });
    }

    handleAddNote(event) {
        const newNote = event.detail;
        console.log('New note added:', newNote);
    }
}

customElements.define('add-note-form', AddNoteForm);
