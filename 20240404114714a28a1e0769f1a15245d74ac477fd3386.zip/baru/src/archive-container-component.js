// archive-container-component.js
class ArchiveContainerComponent extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
      this.shadowRoot.innerHTML = `
        <style>
            .archive-container {
                background-color: #f4f4f4;
                border: 1px solid #ddd;
                border-radius: 5px;
                padding: 10px;
                margin-bottom: 20px;
            }
            
            .archive-title {
                font-size: 18px;
                font-weight: bold;
                margin-bottom: 10px;
            }
            .note {
                background-color: #fff;
                border: 1px solid #ddd;
                border-radius: 5px;
                padding: 10px;
                margin-bottom: 10px;
            }
            .note-title {
                font-weight: bold;
            }
            .note-body {
                padding: 10px;
            }
            button-components {
                display: inline-block;
                background-color: #007bff;
                color: #fff;
                border: none;
                border-radius: 5px;
                padding: 8px 16px;
                margin-right: 8px;
                cursor: pointer;
                font-size: 14px;
                font-weight: bold;
                text-transform: uppercase;
                transition: background-color 0.3s ease;
                outline: none;
            }
            button-components:hover {
                background-color: #0056b3;
            }
        </style>
        <div class="archive-container">
            <div class="archive-title">Ini Tempat Arsip</div>
            <div id="archive-notes"></div>
        </div>
      `;
    }

    connectedCallback() {
      this.renderArchiveNotes();
      this.addEventListener('archive-note', (event) => {
        this.archiveNoteHandler(event.detail.noteId);
      });
      this.addEventListener('unarchive-note', (event) => {
        this.unarchiveNoteHandler(event.detail.noteId);
      });
      this.addEventListener('delete-note', (event) => {
        this.deleteNoteHandler(event.detail.noteId);
      });
    }

    async renderArchiveNotes() {
      const archiveNotesDiv = this.shadowRoot.getElementById('archive-notes');
      try {
        const response = await fetch('https://notes-api.dicoding.dev/v2/notes/archived');
        const data = await response.json();
        if (data.status === "success") {
          const archivedNotes = data.data;
          archiveNotesDiv.innerHTML = ''; 
          if (archivedNotes.length === 0) {
            archiveNotesDiv.textContent = 'No archived notes.';
          } else {
            archivedNotes.forEach(note => {
              const noteElement = document.createElement('div');
              noteElement.classList.add('note');
              noteElement.innerHTML = `
                <div class="note-title">${note.title}</div>
                <div class="note-body">${note.body}</div>
                <button-components text="Unarchive" note-id="${note.id}" action="unarchive"></button-components>
                <button-components text="Delete" note-id="${note.id}" action="delete"></button-components>
              `;
              archiveNotesDiv.appendChild(noteElement);
            });
          }
        } else {
          throw new Error(data.message);
        }
      } catch (error) {
        console.error('Error fetching archived notes:', error);
        archiveNotesDiv.textContent = 'Error fetching archived notes. Please try again later.';
      }
    }

    async unarchiveNoteHandler(noteId) {
      try {
        const response = await fetch(`https://notes-api.dicoding.dev/v2/notes/${noteId}/unarchive`, {
          method: 'POST'
        });
        const data = await response.json();
        if (data.status === "success") {
          this.renderArchiveNotes();
        } else {
          throw new Error(data.message);
        }
      } catch (error) {
        console.error('Error unarchiving note:', error);
      }
    }

    async deleteNoteHandler(noteId) {
      try {
        const response = await fetch(`https://notes-api.dicoding.dev/v2/notes/${noteId}`, {
          method: 'DELETE'
        });
        const data = await response.json();
        if (data.status === "success") {
          this.renderArchiveNotes();
        } else {
          throw new Error(data.message);
        }
      } catch (error) {
        console.error('Error deleting note:', error);
      }
    }
}

customElements.define('archive-container-component', ArchiveContainerComponent);
