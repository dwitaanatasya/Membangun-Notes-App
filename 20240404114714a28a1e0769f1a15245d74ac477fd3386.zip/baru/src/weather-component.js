class WeatherComponent extends HTMLElement {
    constructor() {
      super();
      const shadow = this.attachShadow({ mode: 'open' });
  
      const wrapper = document.createElement('div');
      wrapper.setAttribute('class', 'weather');
  
      const body = document.createElement('div');
      body.setAttribute('class', 'weather-body');
  
      body.textContent = this.getAttribute('body');
  
      wrapper.appendChild(body);
  
      const style = document.createElement('style');
      style.textContent = `
        .weather {
          background-color: #f4f4f4;
          border: 1px solid #ddd;
          border-radius: 5px;
          padding: 10px;
          max-width: 300px;
        }
        
        .weather-body {
          font-size: 14px;
          font-weight: bold;
        }
      `;
  
      shadow.appendChild(style);
      shadow.appendChild(wrapper);
    }
  }
  
  customElements.define('weather-component', WeatherComponent);
