// note-component.js
class NoteComponent extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
          .note-component {
              background-color: #f4f4f4;
              border: 1px solid #ddd;
              border-radius: 5px;
              padding: 10px;
              margin-bottom: 20px;
          }
          button-components {
              display: inline-block;
              background-color: #007bff;
              color: #fff;
              border: none;
              border-radius: 5px;
              padding: 8px 16px;
              margin-right: 8px;
              cursor: pointer;
              font-size: 14px;
              font-weight: bold;
              text-transform: uppercase;
              transition: background-color 0.3s ease;
              outline: none;
          }
          button-components:hover {
              background-color: #0056b3;
          }
          .note-title {
              font-size: 18px;
              font-weight: bold;
              margin-bottom: 10px;
          }
          .note {
              background-color: #fff;
              border: 1px solid #ddd;
              border-radius: 5px;
              padding: 10px;
              margin-bottom: 10px;
          }
          .note-body {
              padding: 10px;
          }
      </style>
      <div class="note-component">
          <div class="note-title">Notes</div>
          <div id="note-body"></div>
      </div>
    `;
  }

  connectedCallback() {
    this.renderNotes();
    this.addEventListener('archive-note', (event) => {
      this.archiveNoteHandler(event.detail.noteId);
    });
    this.addEventListener('delete-note', (event) => {
      this.deleteNoteHandler(event.detail.noteId);
    });
  }

  async renderNotes() {
    const noteBodyDiv = this.shadowRoot.getElementById('note-body');
    try {
      const response = await fetch('https://notes-api.dicoding.dev/v2/notes');
      const data = await response.json();
      if (data.status === "success") {
        const notesData = data.data;
        noteBodyDiv.innerHTML = ''; 
        if (notesData.length === 0) {
          noteBodyDiv.textContent = 'No notes.';
        } else {
          notesData.forEach(note => {
            const noteElement = document.createElement('div');
            noteElement.classList.add('note');
            noteElement.innerHTML = `
              <div class="note-title">${note.title}</div>
              <div class="note-body">${note.body}</div>
              <button-components text="Archive" note-id="${note.id}" action="archive"></button-components>
              <button-components text="Delete" note-id="${note.id}" action="delete"></button-components>
            `;
            noteBodyDiv.appendChild(noteElement);
          });
        }
      } else {
        throw new Error(data.message);
      }
    } catch (error) {
      console.error('Error fetching notes:', error);
      noteBodyDiv.textContent = 'Error fetching notes. Please try again later.';
    }
  }

  async archiveNoteHandler(noteId) {
    try {
      const response = await fetch(`https://notes-api.dicoding.dev/v2/notes/${noteId}/archive`, {
        method: 'POST'
      });
      const data = await response.json();
      if (data.status === "success") {
        this.renderNotes(); 
      } else {
        throw new Error(data.message);
      }
    } catch (error) {
      console.error('Error archiving note:', error);
    }
  }

  async deleteNoteHandler(noteId) {
    try {
      const response = await fetch(`https://notes-api.dicoding.dev/v2/notes/${noteId}`, {
        method: 'DELETE'
      });
      const data = await response.json();
      if (data.status === "success") {
        this.renderNotes(); 
      } else {
        throw new Error(data.message);
      }
    } catch (error) {
      console.error('Error deleting note:', error);
    }
  }
}

customElements.define('notes-component', NoteComponent);
