const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin'); // Tambahkan baris ini

module.exports = {
    mode: 'development',
    entry: './src/script.js',
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: 'bundle.js'
    },
    devServer: {
        static: {
            directory: path.join(__dirname, 'dist'),
        },
        compress: true,
        port: 9000 // Ubah port sesuai kebutuhan Anda
    },
    plugins: [
        new HtmlWebpackPlugin({
            template: './index.html' // Path ke file HTML sumber
        })
    ]
};
