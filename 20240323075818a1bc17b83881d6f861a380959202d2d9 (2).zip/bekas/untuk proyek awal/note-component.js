class NoteComponent extends HTMLElement {
    constructor() {
      super();
      const shadow = this.attachShadow({ mode: 'open' });
  
      const wrapper = document.createElement('div');
      wrapper.setAttribute('class', 'note');
  
      const title = document.createElement('div');
      title.setAttribute('class', 'note-title');
  
      const body = document.createElement('div');
      body.setAttribute('class', 'note-body');
  
      title.textContent = this.getAttribute('title');
      body.textContent = this.getAttribute('body');
  
      wrapper.appendChild(title);
      wrapper.appendChild(body);
  
      const style = document.createElement('style');
      style.textContent = `
        .note {
          background-color: #f4f4f4;
          border: 1px solid #ddd;
          border-radius: 5px;
          padding: 10px;
          max-width: 300px;
        }
        
        .note-title {
          font-weight: bold;
          margin-bottom: 5px;
        }
        
        .note-body {
          font-size: 14px;
        }
      `;
  
      shadow.appendChild(style);
      shadow.appendChild(wrapper);
    }
  }
  
  customElements.define('note-component', NoteComponent);
  