class QuoteComponent extends HTMLElement {
    constructor() {
      super();
      const shadow = this.attachShadow({ mode: 'open' });
  
      const wrapper = document.createElement('div');
      wrapper.setAttribute('class', 'quote');
  
      const body = document.createElement('div');
      body.setAttribute('class', 'quote-body');
  
      body.textContent = this.getAttribute('body');
  
      wrapper.appendChild(body);
  
      const style = document.createElement('style');
      style.textContent = `
        .quote {
          background-color: #f4f4f4;
          border: 1px solid #ddd;
          border-radius: 5px;
          padding: 10px;
          max-width: 300px;
        }
        
        .quote-body {
          font-size: 14px;
          font-style: italic;
        }
      `;
  
      shadow.appendChild(style);
      shadow.appendChild(wrapper);
    }
  }
  
  customElements.define('quote-component', QuoteComponent);
